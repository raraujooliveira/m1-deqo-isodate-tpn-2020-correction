package deqo.isodate;

/**
 * Exception lors du parsing d'une date en ISO 8601.
 */
public class IsoDateException extends Exception {
}
